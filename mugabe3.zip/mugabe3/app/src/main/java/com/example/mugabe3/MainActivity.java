package com.example.mugabe3;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.mugabe3.ml.Model;

import org.tensorflow.lite.DataType;
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    private TextView resultTextView, confidenceTextView;
    private ImageView imageView;
    private Button pictureButton;
    private int imageSize = 256;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        resultTextView = findViewById(R.id.result);
        confidenceTextView = findViewById(R.id.confidence);
        imageView = findViewById(R.id.imageView);
        pictureButton = findViewById(R.id.button);

        // Set click listener for the "Select Picture" button
        pictureButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                    // Launch gallery picker if we have permission
                    Intent pickImageIntent = new Intent(Intent.ACTION_PICK);
                    pickImageIntent.setType("image/*");
                    startActivityForResult(pickImageIntent, 1);
                } else {
                    // Request permission to access the gallery if we don't have it
                    requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 100);
                }
            }
        });
    }

    // Method to classify the input image using the model
    public void classifyImage(Bitmap image) {
        try {
            // Load the pre-trained model
            Model model = Model.newInstance(getApplicationContext());

            // Create input TensorBuffer with shape [1, 1]
            TensorBuffer inputFeature0 = TensorBuffer.createFixedSize(new int[]{1, 1}, DataType.FLOAT32);

            // Preprocess the image if needed and get a single float32 value for the model input
            float inputValue = preprocessImageAndGetSingleValue(image);
            inputFeature0.loadArray(new float[]{inputValue});

            // Run model inference and get the output TensorBuffer
            Model.Outputs outputs = model.process(inputFeature0);
            TensorBuffer outputFeature0 = outputs.getOutputFeature0AsTensorBuffer();

            // Get the confidence values as a float array
            float[] confidences = outputFeature0.getFloatArray();

            // Find the index with the maximum confidence value
            int maxPos = 0;
            float maxConfidence = confidences[0];
            for (int i = 1; i < confidences.length; i++) {
                if (confidences[i] > maxConfidence) {
                    maxConfidence = confidences[i];
                    maxPos = i;
                }
            }

            // Define the classes corresponding to the model output
            String[] classes = {"Amoeba", "Euglena", "Hydra", "Paramecium", "Rod bacteria", "spherical bacteria", "spiral bacteria", "yeast"};

            // Set the result TextView with the predicted class
            resultTextView.setText(classes[maxPos]);

            // Set the confidence TextView with the confidence values for each class
            StringBuilder confidenceText = new StringBuilder();
            for (int i = 0; i < classes.length; i++) {
                confidenceText.append(String.format("%s. %.1f%%\n", classes[i], confidences[i] * 100));
            }
            confidenceTextView.setText(confidenceText.toString());

            // Release model resources if no longer used
            model.close();
        } catch (IOException e) {
            // Handle the exception
            e.printStackTrace();
        }
    }

    // Method to preprocess the input image and get a single float value for the model
    public float preprocessImageAndGetSingleValue(Bitmap image) {
        // Convert the image to grayscale
        Bitmap grayscaleImage = convertToGrayscale(image);

        // Calculate the average pixel value of the grayscale image
        float averagePixelValue = calculateAveragePixelValue(grayscaleImage);

        // Normalize the average pixel value to the range [0, 1]
        return averagePixelValue / 255.0f;
    }

    // Method to convert the input image to grayscale
    private Bitmap convertToGrayscale(Bitmap originalImage) {
        int width = originalImage.getWidth();
        int height = originalImage.getHeight();
        Bitmap grayscaleImage = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);

        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                int pixel = originalImage.getPixel(x, y);
                int red = Color.red(pixel);
                int green = Color.green(pixel);
                int blue = Color.blue(pixel);

                // Convert to grayscale using the luminance formula (Y = 0.299R + 0.587G + 0.114B)
                int grayValue = (int) (0.299 * red + 0.587 * green + 0.114 * blue);

                // Set the pixel value in the grayscale image
                grayscaleImage.setPixel(x, y, Color.rgb(grayValue, grayValue, grayValue));
            }
        }

        return grayscaleImage;
    }

    // Method to calculate the average pixel value of the input image
    private float calculateAveragePixelValue(Bitmap image) {
        int width = image.getWidth();
        int height = image.getHeight();
        int totalPixels = width * height;
        int[] pixels = new int[totalPixels];
        image.getPixels(pixels, 0, width, 0, 0, width, height);

        int sumPixelValue = 0;
        for (int pixel : pixels) {
            int grayValue = Color.red(pixel); // Since the image is grayscale, R, G, and B values are the same
            sumPixelValue += grayValue;
        }

        return (float) sumPixelValue / totalPixels;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {

            // Get the selected image from the intent
            Uri selectedImage = data.getData();
            try {
                // Convert the image to a Bitmap
                Bitmap originalImage = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImage);

                // Resize the image to the expected input size of the model (256x256)
                Bitmap resizedImage = Bitmap.createScaledBitmap(originalImage, imageSize, imageSize, false);

                // Set the bitmap in the ImageView preview
                imageView.setImageBitmap(resizedImage);

                // Pass the Bitmap to the classifyImage() method for processing
                classifyImage(resizedImage);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}